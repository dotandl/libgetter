#!/bin/sh
build() {
  echo "Hello world!"
}

#!/bin/sh

prepare() { exit; }

build() {
  echo "Hello world!"
}

install() { exit; }
clean() { exit; }
